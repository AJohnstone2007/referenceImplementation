
The applications in this area are not general purpose, and are generally
designed to be used for functional testing.
